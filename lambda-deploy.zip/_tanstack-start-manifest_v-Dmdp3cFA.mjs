//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dmdp3cFA.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/Mine/WebstormProjects/untitled/lisa-lite/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["https://lisa-lite-207871832731.s3.eu-central-1.amazonaws.com/assets/index--ndE_ude.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "https://lisa-lite-207871832731.s3.eu-central-1.amazonaws.com/assets/index--ndE_ude.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/Mine/WebstormProjects/untitled/lisa-lite/src/routes/index.tsx",
		children: void 0,
		preloads: ["https://lisa-lite-207871832731.s3.eu-central-1.amazonaws.com/assets/routes-Cg3mBJMn.js"]
	}
} });
//#endregion
export { tsrStartManifest };
