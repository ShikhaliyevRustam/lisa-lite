import { a as require_retry, c as require_checksum, d as require_config, f as require_client, i as require_dist_cjs, l as require_serde, o as require_protocols, p as require_schema, r as require_client$1, u as require_endpoints } from "./checksums+[...].mjs";
import { a as init_dist_es, c as defaultProvider, d as require_protocols$1, i as import_serde$1, o as NodeHttpHandler, u as require_httpAuthSchemes } from "./client-s3+[...].mjs";
//#region node_modules/@aws-sdk/middleware-sdk-sqs/dist-es/queue-url.js
var import_client$1 = require_client();
var resolveQueueUrlConfig = (config) => {
	return Object.assign(config, { useQueueUrlAsEndpoint: config.useQueueUrlAsEndpoint ?? true });
};
function queueUrlMiddleware({ useQueueUrlAsEndpoint, endpoint }) {
	return (next, context) => {
		return async (args) => {
			const { input } = args;
			const resolvedEndpoint = context.endpointV2;
			if (!endpoint && input.QueueUrl && resolvedEndpoint && useQueueUrlAsEndpoint) {
				const logger = context.logger instanceof import_client$1.NoOpLogger || !context.logger?.warn ? console : context.logger;
				try {
					const queueUrl = new URL(input.QueueUrl);
					const queueUrlOrigin = new URL(queueUrl.origin);
					if (resolvedEndpoint.url.origin !== queueUrlOrigin.origin) {
						logger.warn(`QueueUrl=${input.QueueUrl} differs from SQSClient resolved endpoint=${resolvedEndpoint.url.toString()}, using QueueUrl host as endpoint.
Set [endpoint=string] or [useQueueUrlAsEndpoint=false] on the SQSClient.`);
						context.endpointV2 = {
							...resolvedEndpoint,
							url: queueUrlOrigin
						};
					}
				} catch (e) {
					logger.warn(e);
				}
			}
			return next(args);
		};
	};
}
var queueUrlMiddlewareOptions = {
	name: "queueUrlMiddleware",
	relation: "after",
	toMiddleware: "endpointV2Middleware",
	override: true
};
var getQueueUrlPlugin = (config) => ({ applyToStack: (clientStack) => {
	clientStack.addRelativeTo(queueUrlMiddleware(config), queueUrlMiddlewareOptions);
} });
//#endregion
//#region node_modules/@aws-sdk/middleware-sdk-sqs/dist-es/send-message.js
var import_serde = require_serde();
var sendMessageMiddleware = (options) => (next) => async (args) => {
	const resp = await next({ ...args });
	if (options.md5 === false) return resp;
	const output = resp.output;
	const hash = new options.md5();
	hash.update((0, import_serde.toUint8Array)(args.input.MessageBody || ""));
	if (output.MD5OfMessageBody !== (0, import_serde.toHex)(await hash.digest())) throw new Error("InvalidChecksumError");
	return resp;
};
var sendMessageMiddlewareOptions = {
	step: "initialize",
	tags: ["VALIDATE_BODY_MD5"],
	name: "sendMessageMiddleware",
	override: true
};
var getSendMessagePlugin = (config) => ({ applyToStack: (clientStack) => {
	clientStack.add(sendMessageMiddleware(config), sendMessageMiddlewareOptions);
} });
//#endregion
//#region node_modules/@aws-sdk/client-sqs/dist-es/auth/httpAuthSchemeProvider.js
var import_schema = require_schema();
var import_config = require_config();
var import_endpoints = require_endpoints();
var import_protocols$1 = require_protocols();
var import_retry = require_retry();
var import_dist_cjs = require_dist_cjs();
var import_client = require_client$1();
var import_httpAuthSchemes = require_httpAuthSchemes();
var defaultSQSHttpAuthSchemeParametersProvider = async (config, context, input) => {
	return {
		operation: (0, import_client$1.getSmithyContext)(context).operation,
		region: await (0, import_client$1.normalizeProvider)(config.region)() || (() => {
			throw new Error("expected `region` to be configured for `aws.auth#sigv4`");
		})()
	};
};
function createAwsAuthSigv4HttpAuthOption(authParameters) {
	return {
		schemeId: "aws.auth#sigv4",
		signingProperties: {
			name: "sqs",
			region: authParameters.region
		},
		propertiesExtractor: (config, context) => ({ signingProperties: {
			config,
			context
		} })
	};
}
var defaultSQSHttpAuthSchemeProvider = (authParameters) => {
	const options = [];
	switch (authParameters.operation) {
		default: options.push(createAwsAuthSigv4HttpAuthOption(authParameters));
	}
	return options;
};
var resolveHttpAuthSchemeConfig = (config) => {
	const config_0 = (0, import_httpAuthSchemes.resolveAwsSdkSigV4Config)(config);
	return Object.assign(config_0, { authSchemePreference: (0, import_client$1.normalizeProvider)(config.authSchemePreference ?? []) });
};
//#endregion
//#region node_modules/@aws-sdk/client-sqs/dist-es/endpoint/EndpointParameters.js
var resolveClientEndpointParameters = (options) => {
	return Object.assign(options, {
		useDualstackEndpoint: options.useDualstackEndpoint ?? false,
		useFipsEndpoint: options.useFipsEndpoint ?? false,
		defaultSigningName: "sqs"
	});
};
var commonParams = {
	UseFIPS: {
		type: "builtInParams",
		name: "useFipsEndpoint"
	},
	Endpoint: {
		type: "builtInParams",
		name: "endpoint"
	},
	Region: {
		type: "builtInParams",
		name: "region"
	},
	UseDualStack: {
		type: "builtInParams",
		name: "useDualstackEndpoint"
	}
};
var package_default = {
	name: "@aws-sdk/client-sqs",
	version: "3.1144.0",
	description: "AWS SDK for JavaScript Sqs Client for Node.js, Browser and React Native",
	homepage: "https://github.com/aws/aws-sdk-js-v3/tree/main/clients/client-sqs",
	license: "Apache-2.0",
	author: {
		"name": "AWS SDK for JavaScript Team",
		"url": "https://aws.amazon.com/sdk-for-javascript/"
	},
	repository: {
		"type": "git",
		"url": "https://github.com/aws/aws-sdk-js-v3.git",
		"directory": "clients/client-sqs"
	},
	files: ["dist-*/**"],
	sideEffects: false,
	main: "./dist-cjs/index.js",
	module: "./dist-es/index.js",
	browser: { "./dist-es/runtimeConfig": "./dist-es/runtimeConfig.browser" },
	types: "./dist-types/index.d.ts",
	typesVersions: { "<4.5": { "dist-types/*": ["dist-types/ts3.4/*"] } },
	"react-native": { "./dist-es/runtimeConfig": "./dist-es/runtimeConfig.native" },
	scripts: {
		"build": "concurrently 'yarn:build:types' 'yarn:build:es' && yarn build:cjs",
		"build:cjs": "node ../../scripts/compilation/inline",
		"build:es": "premove dist-es && tsc -p tsconfig.es.json",
		"build:include:deps": "yarn g:turbo run build -F=\"$npm_package_name\"",
		"build:types": "premove dist-types && tsc -p tsconfig.types.json",
		"build:types:downlevel": "downlevel-dts dist-types dist-types/ts3.4",
		"clean": "premove dist-cjs dist-es dist-types",
		"extract:docs": "api-extractor run --local",
		"generate:client": "node ../../scripts/generate-clients/single-service",
		"test": "yarn g:vitest run --passWithNoTests",
		"test:watch": "yarn g:vitest watch --passWithNoTests",
		"test:integration": "yarn g:vitest run --passWithNoTests -c vitest.config.integ.mts",
		"test:integration:watch": "yarn g:vitest watch --passWithNoTests -c vitest.config.integ.mts",
		"test:e2e": "yarn g:vitest run -c vitest.config.e2e.mts",
		"test:e2e:watch": "yarn g:vitest watch -c vitest.config.e2e.mts",
		"test:browser": "yarn g:vitest run -c vitest.config.browser.e2e.mts",
		"test:browser:watch": "yarn g:vitest watch -c vitest.config.browser.e2e.mts",
		"test:index": "tsc -p tsconfig.test.json && node ./test/index-objects.spec.mjs"
	},
	dependencies: {
		"@aws-sdk/core": "^3.978.1",
		"@aws-sdk/credential-provider-node": "^3.972.84",
		"@aws-sdk/middleware-sdk-sqs": "^3.972.43",
		"@aws-sdk/types": "^3.974.6",
		"@smithy/core": "^3.35.0",
		"@smithy/fetch-http-handler": "^5.8.0",
		"@smithy/node-http-handler": "^4.12.1",
		"@smithy/types": "^4.19.0",
		"tslib": "^2.6.2"
	},
	devDependencies: {
		"@smithy/snapshot-testing": "^2.3.2",
		"@tsconfig/node20": "20.1.8",
		"@types/node": "^20.14.8",
		"concurrently": "7.0.0",
		"downlevel-dts": "0.10.1",
		"premove": "4.0.0",
		"typescript": "~7.0.2",
		"vitest": "^4.0.17"
	},
	engines: { "node": ">=20.0.0" }
};
//#endregion
//#region node_modules/@aws-sdk/client-sqs/dist-es/endpoint/bdd.js
var import_checksum = require_checksum();
var import_protocols = require_protocols$1();
init_dist_es();
var k = "ref";
var a = -1;
var b = true;
var c = "isSet";
var d = "PartitionResult";
var e = "booleanEquals";
var f = "getAttr";
var g = { [k]: "Endpoint" };
var h = { [k]: d };
var i = {};
var j = [{ [k]: "Region" }];
var _data = {
	conditions: [
		[c, [g]],
		[c, j],
		[
			"aws.partition",
			j,
			d
		],
		[e, [{ [k]: "UseFIPS" }, b]],
		[e, [{ [k]: "UseDualStack" }, b]],
		[e, [{
			fn: f,
			argv: [h, "supportsDualStack"]
		}, b]],
		[e, [{
			fn: f,
			argv: [h, "supportsFIPS"]
		}, b]],
		["stringEquals", [{
			fn: f,
			argv: [h, "name"]
		}, "aws-us-gov"]]
	],
	results: [
		[a],
		[a, "Invalid Configuration: FIPS and custom endpoint are not supported"],
		[a, "Invalid Configuration: Dualstack and custom endpoint are not supported"],
		[g, i],
		["https://sqs-fips.{Region}.{PartitionResult#dualStackDnsSuffix}", i],
		[a, "FIPS and DualStack are enabled, but this partition does not support one or both"],
		["https://sqs.{Region}.amazonaws.com", i],
		["https://sqs-fips.{Region}.{PartitionResult#dnsSuffix}", i],
		[a, "FIPS is enabled but this partition does not support FIPS"],
		["https://sqs.{Region}.{PartitionResult#dualStackDnsSuffix}", i],
		[a, "DualStack is enabled but this partition does not support DualStack"],
		["https://sqs.{Region}.{PartitionResult#dnsSuffix}", i],
		[a, "Invalid Configuration: Missing Region"]
	]
};
var root = 2;
var nodes = new Int32Array([
	-1,
	1,
	-1,
	0,
	13,
	3,
	1,
	4,
	100000012,
	2,
	5,
	100000012,
	3,
	8,
	6,
	4,
	7,
	100000011,
	5,
	100000009,
	100000010,
	4,
	11,
	9,
	6,
	10,
	100000008,
	7,
	100000006,
	100000007,
	5,
	12,
	100000005,
	6,
	100000004,
	100000005,
	3,
	100000001,
	14,
	4,
	100000002,
	100000003
]);
var bdd = import_endpoints.BinaryDecisionDiagram.from(nodes, root, _data.conditions, _data.results);
//#endregion
//#region node_modules/@aws-sdk/client-sqs/dist-es/endpoint/endpointResolver.js
var cache = new import_endpoints.EndpointCache({
	size: 50,
	params: [
		"Endpoint",
		"Region",
		"UseDualStack",
		"UseFIPS"
	]
});
var defaultEndpointResolver = (endpointParams, context = {}) => {
	return cache.get(endpointParams, () => (0, import_endpoints.decideEndpoint)(bdd, {
		endpointParams,
		logger: context.logger
	}));
};
import_endpoints.customEndpointFunctions.aws = import_client.awsEndpointFunctions;
//#endregion
//#region node_modules/@aws-sdk/client-sqs/dist-es/models/SQSServiceException.js
var SQSServiceException = class SQSServiceException extends import_client$1.ServiceException {
	constructor(options) {
		super(options);
		Object.setPrototypeOf(this, SQSServiceException.prototype);
	}
};
//#endregion
//#region node_modules/@aws-sdk/client-sqs/dist-es/models/errors.js
var InvalidAddress = class InvalidAddress extends SQSServiceException {
	name = "InvalidAddress";
	$fault = "client";
	constructor(opts) {
		super({
			name: "InvalidAddress",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, InvalidAddress.prototype);
	}
};
var InvalidSecurity = class InvalidSecurity extends SQSServiceException {
	name = "InvalidSecurity";
	$fault = "client";
	constructor(opts) {
		super({
			name: "InvalidSecurity",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, InvalidSecurity.prototype);
	}
};
var OverLimit = class OverLimit extends SQSServiceException {
	name = "OverLimit";
	$fault = "client";
	constructor(opts) {
		super({
			name: "OverLimit",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, OverLimit.prototype);
	}
};
var QueueDoesNotExist = class QueueDoesNotExist extends SQSServiceException {
	name = "QueueDoesNotExist";
	$fault = "client";
	constructor(opts) {
		super({
			name: "QueueDoesNotExist",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, QueueDoesNotExist.prototype);
	}
};
var RequestThrottled = class RequestThrottled extends SQSServiceException {
	name = "RequestThrottled";
	$fault = "client";
	constructor(opts) {
		super({
			name: "RequestThrottled",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, RequestThrottled.prototype);
	}
};
var UnsupportedOperation = class UnsupportedOperation extends SQSServiceException {
	name = "UnsupportedOperation";
	$fault = "client";
	constructor(opts) {
		super({
			name: "UnsupportedOperation",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, UnsupportedOperation.prototype);
	}
};
var ResourceNotFoundException = class ResourceNotFoundException extends SQSServiceException {
	name = "ResourceNotFoundException";
	$fault = "client";
	constructor(opts) {
		super({
			name: "ResourceNotFoundException",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, ResourceNotFoundException.prototype);
	}
};
var MessageNotInflight = class MessageNotInflight extends SQSServiceException {
	name = "MessageNotInflight";
	$fault = "client";
	constructor(opts) {
		super({
			name: "MessageNotInflight",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, MessageNotInflight.prototype);
	}
};
var ReceiptHandleIsInvalid = class ReceiptHandleIsInvalid extends SQSServiceException {
	name = "ReceiptHandleIsInvalid";
	$fault = "client";
	constructor(opts) {
		super({
			name: "ReceiptHandleIsInvalid",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, ReceiptHandleIsInvalid.prototype);
	}
};
var BatchEntryIdsNotDistinct = class BatchEntryIdsNotDistinct extends SQSServiceException {
	name = "BatchEntryIdsNotDistinct";
	$fault = "client";
	constructor(opts) {
		super({
			name: "BatchEntryIdsNotDistinct",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, BatchEntryIdsNotDistinct.prototype);
	}
};
var EmptyBatchRequest = class EmptyBatchRequest extends SQSServiceException {
	name = "EmptyBatchRequest";
	$fault = "client";
	constructor(opts) {
		super({
			name: "EmptyBatchRequest",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, EmptyBatchRequest.prototype);
	}
};
var InvalidBatchEntryId = class InvalidBatchEntryId extends SQSServiceException {
	name = "InvalidBatchEntryId";
	$fault = "client";
	constructor(opts) {
		super({
			name: "InvalidBatchEntryId",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, InvalidBatchEntryId.prototype);
	}
};
var TooManyEntriesInBatchRequest = class TooManyEntriesInBatchRequest extends SQSServiceException {
	name = "TooManyEntriesInBatchRequest";
	$fault = "client";
	constructor(opts) {
		super({
			name: "TooManyEntriesInBatchRequest",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, TooManyEntriesInBatchRequest.prototype);
	}
};
var InvalidAttributeName = class InvalidAttributeName extends SQSServiceException {
	name = "InvalidAttributeName";
	$fault = "client";
	constructor(opts) {
		super({
			name: "InvalidAttributeName",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, InvalidAttributeName.prototype);
	}
};
var InvalidAttributeValue = class InvalidAttributeValue extends SQSServiceException {
	name = "InvalidAttributeValue";
	$fault = "client";
	constructor(opts) {
		super({
			name: "InvalidAttributeValue",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, InvalidAttributeValue.prototype);
	}
};
var QueueDeletedRecently = class QueueDeletedRecently extends SQSServiceException {
	name = "QueueDeletedRecently";
	$fault = "client";
	constructor(opts) {
		super({
			name: "QueueDeletedRecently",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, QueueDeletedRecently.prototype);
	}
};
var QueueNameExists = class QueueNameExists extends SQSServiceException {
	name = "QueueNameExists";
	$fault = "client";
	constructor(opts) {
		super({
			name: "QueueNameExists",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, QueueNameExists.prototype);
	}
};
var InvalidIdFormat = class InvalidIdFormat extends SQSServiceException {
	name = "InvalidIdFormat";
	$fault = "client";
	constructor(opts) {
		super({
			name: "InvalidIdFormat",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, InvalidIdFormat.prototype);
	}
};
var PurgeQueueInProgress = class PurgeQueueInProgress extends SQSServiceException {
	name = "PurgeQueueInProgress";
	$fault = "client";
	constructor(opts) {
		super({
			name: "PurgeQueueInProgress",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, PurgeQueueInProgress.prototype);
	}
};
var KmsAccessDenied = class KmsAccessDenied extends SQSServiceException {
	name = "KmsAccessDenied";
	$fault = "client";
	constructor(opts) {
		super({
			name: "KmsAccessDenied",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, KmsAccessDenied.prototype);
	}
};
var KmsDisabled = class KmsDisabled extends SQSServiceException {
	name = "KmsDisabled";
	$fault = "client";
	constructor(opts) {
		super({
			name: "KmsDisabled",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, KmsDisabled.prototype);
	}
};
var KmsInvalidKeyUsage = class KmsInvalidKeyUsage extends SQSServiceException {
	name = "KmsInvalidKeyUsage";
	$fault = "client";
	constructor(opts) {
		super({
			name: "KmsInvalidKeyUsage",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, KmsInvalidKeyUsage.prototype);
	}
};
var KmsInvalidState = class KmsInvalidState extends SQSServiceException {
	name = "KmsInvalidState";
	$fault = "client";
	constructor(opts) {
		super({
			name: "KmsInvalidState",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, KmsInvalidState.prototype);
	}
};
var KmsNotFound = class KmsNotFound extends SQSServiceException {
	name = "KmsNotFound";
	$fault = "client";
	constructor(opts) {
		super({
			name: "KmsNotFound",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, KmsNotFound.prototype);
	}
};
var KmsOptInRequired = class KmsOptInRequired extends SQSServiceException {
	name = "KmsOptInRequired";
	$fault = "client";
	constructor(opts) {
		super({
			name: "KmsOptInRequired",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, KmsOptInRequired.prototype);
	}
};
var KmsThrottled = class KmsThrottled extends SQSServiceException {
	name = "KmsThrottled";
	$fault = "client";
	constructor(opts) {
		super({
			name: "KmsThrottled",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, KmsThrottled.prototype);
	}
};
var InvalidMessageContents = class InvalidMessageContents extends SQSServiceException {
	name = "InvalidMessageContents";
	$fault = "client";
	constructor(opts) {
		super({
			name: "InvalidMessageContents",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, InvalidMessageContents.prototype);
	}
};
var BatchRequestTooLong = class BatchRequestTooLong extends SQSServiceException {
	name = "BatchRequestTooLong";
	$fault = "client";
	constructor(opts) {
		super({
			name: "BatchRequestTooLong",
			$fault: "client",
			...opts
		});
		Object.setPrototypeOf(this, BatchRequestTooLong.prototype);
	}
};
//#endregion
//#region node_modules/@aws-sdk/client-sqs/dist-es/schemas/schemas_0.js
var _BEIND = "BatchEntryIdsNotDistinct";
var _BL = "BinaryList";
var _BLV = "BinaryListValues";
var _BLVi = "BinaryListValue";
var _BRTL = "BatchRequestTooLong";
var _BV = "BinaryValue";
var _DS = "DelaySeconds";
var _DT = "DataType";
var _EBR = "EmptyBatchRequest";
var _IA = "InvalidAddress";
var _IAN = "InvalidAttributeName";
var _IAV = "InvalidAttributeValue";
var _IBEI = "InvalidBatchEntryId";
var _IIF = "InvalidIdFormat";
var _IMC = "InvalidMessageContents";
var _IS = "InvalidSecurity";
var _KAD = "KmsAccessDenied";
var _KD = "KmsDisabled";
var _KIKU = "KmsInvalidKeyUsage";
var _KIS = "KmsInvalidState";
var _KNF = "KmsNotFound";
var _KOIR = "KmsOptInRequired";
var _KT = "KmsThrottled";
var _MA = "MessageAttributes";
var _MAV = "MessageAttributeValue";
var _MAe = "MessageAttribute";
var _MB = "MessageBody";
var _MBAM = "MessageBodyAttributeMap";
var _MBSAM = "MessageBodySystemAttributeMap";
var _MDI = "MessageDeduplicationId";
var _MDOMA = "MD5OfMessageAttributes";
var _MDOMB = "MD5OfMessageBody";
var _MDOMSA = "MD5OfMessageSystemAttributes";
var _MGI = "MessageGroupId";
var _MI = "MessageId";
var _MNI = "MessageNotInflight";
var _MSA = "MessageSystemAttributes";
var _MSAV = "MessageSystemAttributeValue";
var _MSAe = "MessageSystemAttribute";
var _N = "Name";
var _OL = "OverLimit";
var _PQIP = "PurgeQueueInProgress";
var _QDNE = "QueueDoesNotExist";
var _QDR = "QueueDeletedRecently";
var _QNE = "QueueNameExists";
var _QU = "QueueUrl";
var _RHII = "ReceiptHandleIsInvalid";
var _RNFE = "ResourceNotFoundException";
var _RT = "RequestThrottled";
var _SL = "StringList";
var _SLV = "StringListValues";
var _SLVt = "StringListValue";
var _SM = "SendMessage";
var _SMR = "SendMessageRequest";
var _SMRe = "SendMessageResult";
var _SN = "SequenceNumber";
var _SV = "StringValue";
var _TMEIBR = "TooManyEntriesInBatchRequest";
var _UO = "UnsupportedOperation";
var _V = "Value";
var _aQE = "awsQueryError";
var _c = "client";
var _e = "error";
var _hE = "httpError";
var _m = "message";
var _s = "smithy.ts.sdk.synthetic.com.amazonaws.sqs";
var _xF = "xmlFlattened";
var _xN = "xmlName";
var n0 = "com.amazonaws.sqs";
var _s_registry = new import_schema.TypeRegistry(_s);
var SQSServiceException$ = [
	-3,
	_s,
	"SQSServiceException",
	0,
	[],
	[]
];
_s_registry.registerError(SQSServiceException$, SQSServiceException);
var n0_registry = new import_schema.TypeRegistry(n0);
var BatchEntryIdsNotDistinct$ = [
	-3,
	n0,
	_BEIND,
	{
		[_aQE]: [`AWS.SimpleQueueService.BatchEntryIdsNotDistinct`, 400],
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(BatchEntryIdsNotDistinct$, BatchEntryIdsNotDistinct);
var BatchRequestTooLong$ = [
	-3,
	n0,
	_BRTL,
	{
		[_aQE]: [`AWS.SimpleQueueService.BatchRequestTooLong`, 400],
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(BatchRequestTooLong$, BatchRequestTooLong);
var EmptyBatchRequest$ = [
	-3,
	n0,
	_EBR,
	{
		[_aQE]: [`AWS.SimpleQueueService.EmptyBatchRequest`, 400],
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(EmptyBatchRequest$, EmptyBatchRequest);
var InvalidAddress$ = [
	-3,
	n0,
	_IA,
	{
		[_aQE]: [`InvalidAddress`, 404],
		[_e]: _c,
		[_hE]: 404
	},
	[_m],
	[0]
];
n0_registry.registerError(InvalidAddress$, InvalidAddress);
var InvalidAttributeName$ = [
	-3,
	n0,
	_IAN,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(InvalidAttributeName$, InvalidAttributeName);
var InvalidAttributeValue$ = [
	-3,
	n0,
	_IAV,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(InvalidAttributeValue$, InvalidAttributeValue);
var InvalidBatchEntryId$ = [
	-3,
	n0,
	_IBEI,
	{
		[_aQE]: [`AWS.SimpleQueueService.InvalidBatchEntryId`, 400],
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(InvalidBatchEntryId$, InvalidBatchEntryId);
var InvalidIdFormat$ = [
	-3,
	n0,
	_IIF,
	{ [_e]: _c },
	[],
	[]
];
n0_registry.registerError(InvalidIdFormat$, InvalidIdFormat);
var InvalidMessageContents$ = [
	-3,
	n0,
	_IMC,
	{ [_e]: _c },
	[_m],
	[0]
];
n0_registry.registerError(InvalidMessageContents$, InvalidMessageContents);
var InvalidSecurity$ = [
	-3,
	n0,
	_IS,
	{
		[_aQE]: [`InvalidSecurity`, 403],
		[_e]: _c,
		[_hE]: 403
	},
	[_m],
	[0]
];
n0_registry.registerError(InvalidSecurity$, InvalidSecurity);
var KmsAccessDenied$ = [
	-3,
	n0,
	_KAD,
	{
		[_aQE]: [`KMS.AccessDeniedException`, 400],
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(KmsAccessDenied$, KmsAccessDenied);
var KmsDisabled$ = [
	-3,
	n0,
	_KD,
	{
		[_aQE]: [`KMS.DisabledException`, 400],
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(KmsDisabled$, KmsDisabled);
var KmsInvalidKeyUsage$ = [
	-3,
	n0,
	_KIKU,
	{
		[_aQE]: [`KMS.InvalidKeyUsageException`, 400],
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(KmsInvalidKeyUsage$, KmsInvalidKeyUsage);
var KmsInvalidState$ = [
	-3,
	n0,
	_KIS,
	{
		[_aQE]: [`KMS.InvalidStateException`, 400],
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(KmsInvalidState$, KmsInvalidState);
var KmsNotFound$ = [
	-3,
	n0,
	_KNF,
	{
		[_aQE]: [`KMS.NotFoundException`, 400],
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(KmsNotFound$, KmsNotFound);
var KmsOptInRequired$ = [
	-3,
	n0,
	_KOIR,
	{
		[_aQE]: [`KMS.OptInRequired`, 403],
		[_e]: _c,
		[_hE]: 403
	},
	[_m],
	[0]
];
n0_registry.registerError(KmsOptInRequired$, KmsOptInRequired);
var KmsThrottled$ = [
	-3,
	n0,
	_KT,
	{
		[_aQE]: [`KMS.ThrottlingException`, 400],
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(KmsThrottled$, KmsThrottled);
var MessageNotInflight$ = [
	-3,
	n0,
	_MNI,
	{
		[_aQE]: [`AWS.SimpleQueueService.MessageNotInflight`, 400],
		[_e]: _c,
		[_hE]: 400
	},
	[],
	[]
];
n0_registry.registerError(MessageNotInflight$, MessageNotInflight);
var OverLimit$ = [
	-3,
	n0,
	_OL,
	{
		[_aQE]: [`OverLimit`, 403],
		[_e]: _c,
		[_hE]: 403
	},
	[_m],
	[0]
];
n0_registry.registerError(OverLimit$, OverLimit);
var PurgeQueueInProgress$ = [
	-3,
	n0,
	_PQIP,
	{
		[_aQE]: [`AWS.SimpleQueueService.PurgeQueueInProgress`, 403],
		[_e]: _c,
		[_hE]: 403
	},
	[_m],
	[0]
];
n0_registry.registerError(PurgeQueueInProgress$, PurgeQueueInProgress);
var QueueDeletedRecently$ = [
	-3,
	n0,
	_QDR,
	{
		[_aQE]: [`AWS.SimpleQueueService.QueueDeletedRecently`, 400],
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(QueueDeletedRecently$, QueueDeletedRecently);
var QueueDoesNotExist$ = [
	-3,
	n0,
	_QDNE,
	{
		[_aQE]: [`AWS.SimpleQueueService.NonExistentQueue`, 400],
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(QueueDoesNotExist$, QueueDoesNotExist);
var QueueNameExists$ = [
	-3,
	n0,
	_QNE,
	{
		[_aQE]: [`QueueAlreadyExists`, 400],
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(QueueNameExists$, QueueNameExists);
var ReceiptHandleIsInvalid$ = [
	-3,
	n0,
	_RHII,
	{
		[_aQE]: [`ReceiptHandleIsInvalid`, 404],
		[_e]: _c,
		[_hE]: 404
	},
	[_m],
	[0]
];
n0_registry.registerError(ReceiptHandleIsInvalid$, ReceiptHandleIsInvalid);
var RequestThrottled$ = [
	-3,
	n0,
	_RT,
	{
		[_aQE]: [`RequestThrottled`, 403],
		[_e]: _c,
		[_hE]: 403
	},
	[_m],
	[0]
];
n0_registry.registerError(RequestThrottled$, RequestThrottled);
var ResourceNotFoundException$ = [
	-3,
	n0,
	_RNFE,
	{
		[_aQE]: [`ResourceNotFoundException`, 404],
		[_e]: _c,
		[_hE]: 404
	},
	[_m],
	[0]
];
n0_registry.registerError(ResourceNotFoundException$, ResourceNotFoundException);
var TooManyEntriesInBatchRequest$ = [
	-3,
	n0,
	_TMEIBR,
	{
		[_aQE]: [`AWS.SimpleQueueService.TooManyEntriesInBatchRequest`, 400],
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(TooManyEntriesInBatchRequest$, TooManyEntriesInBatchRequest);
var UnsupportedOperation$ = [
	-3,
	n0,
	_UO,
	{
		[_aQE]: [`AWS.SimpleQueueService.UnsupportedOperation`, 400],
		[_e]: _c,
		[_hE]: 400
	},
	[_m],
	[0]
];
n0_registry.registerError(UnsupportedOperation$, UnsupportedOperation);
var errorTypeRegistries = [_s_registry, n0_registry];
var MessageAttributeValue$ = [
	3,
	n0,
	_MAV,
	0,
	[
		_DT,
		_SV,
		_BV,
		_SLV,
		_BLV
	],
	[
		0,
		0,
		21,
		[() => StringList, {
			[_xF]: 1,
			[_xN]: _SLVt
		}],
		[() => BinaryList, {
			[_xF]: 1,
			[_xN]: _BLVi
		}]
	],
	1
];
var MessageSystemAttributeValue$ = [
	3,
	n0,
	_MSAV,
	0,
	[
		_DT,
		_SV,
		_BV,
		_SLV,
		_BLV
	],
	[
		0,
		0,
		21,
		[() => StringList, {
			[_xF]: 1,
			[_xN]: _SLVt
		}],
		[() => BinaryList, {
			[_xF]: 1,
			[_xN]: _BLVi
		}]
	],
	1
];
var SendMessageRequest$ = [
	3,
	n0,
	_SMR,
	0,
	[
		_QU,
		_MB,
		_DS,
		_MA,
		_MSA,
		_MDI,
		_MGI
	],
	[
		0,
		0,
		1,
		[() => MessageBodyAttributeMap, {
			[_xF]: 1,
			[_xN]: _MAe
		}],
		[() => MessageBodySystemAttributeMap, {
			[_xF]: 1,
			[_xN]: _MSAe
		}],
		0,
		0
	],
	2
];
var SendMessageResult$ = [
	3,
	n0,
	_SMRe,
	0,
	[
		_MDOMB,
		_MDOMA,
		_MDOMSA,
		_MI,
		_SN
	],
	[
		0,
		0,
		0,
		0,
		0
	]
];
var BinaryList = [
	1,
	n0,
	_BL,
	0,
	[21, { [_xN]: _BLVi }]
];
var StringList = [
	1,
	n0,
	_SL,
	0,
	[0, { [_xN]: _SLVt }]
];
var MessageBodyAttributeMap = [
	2,
	n0,
	_MBAM,
	0,
	[0, { [_xN]: _N }],
	[() => MessageAttributeValue$, { [_xN]: _V }]
];
var MessageBodySystemAttributeMap = [
	2,
	n0,
	_MBSAM,
	0,
	[0, { [_xN]: _N }],
	[() => MessageSystemAttributeValue$, { [_xN]: _V }]
];
var SendMessage$ = [
	9,
	n0,
	_SM,
	0,
	() => SendMessageRequest$,
	() => SendMessageResult$
];
//#endregion
//#region node_modules/@aws-sdk/client-sqs/dist-es/runtimeConfig.shared.js
var getRuntimeConfig$1 = (config) => {
	return {
		apiVersion: "2012-11-05",
		base64Decoder: config?.base64Decoder ?? import_serde.fromBase64,
		base64Encoder: config?.base64Encoder ?? import_serde.toBase64,
		disableHostPrefix: config?.disableHostPrefix ?? false,
		endpointProvider: config?.endpointProvider ?? defaultEndpointResolver,
		extensions: config?.extensions ?? [],
		httpAuthSchemeProvider: config?.httpAuthSchemeProvider ?? defaultSQSHttpAuthSchemeProvider,
		httpAuthSchemes: config?.httpAuthSchemes ?? [{
			schemeId: "aws.auth#sigv4",
			identityProvider: (ipc) => ipc.getIdentityProvider("aws.auth#sigv4"),
			signer: new import_httpAuthSchemes.AwsSdkSigV4Signer()
		}],
		logger: config?.logger ?? new import_client$1.NoOpLogger(),
		md5: config?.md5 ?? import_checksum.Md5,
		protocol: config?.protocol ?? import_protocols.AwsJson1_0Protocol,
		protocolSettings: config?.protocolSettings ?? {
			defaultNamespace: "com.amazonaws.sqs",
			errorTypeRegistries,
			version: "2012-11-05",
			serviceTarget: "AmazonSQS",
			awsQueryCompatible: true
		},
		serviceId: config?.serviceId ?? "SQS",
		sha256: config?.sha256 ?? import_checksum.Sha256,
		urlParser: config?.urlParser ?? import_protocols$1.parseUrl,
		utf8Decoder: config?.utf8Decoder ?? import_serde.fromUtf8,
		utf8Encoder: config?.utf8Encoder ?? import_serde.toUtf8
	};
};
//#endregion
//#region node_modules/@aws-sdk/client-sqs/dist-es/runtimeConfig.js
var getRuntimeConfig = (config) => {
	(0, import_client$1.emitWarningIfUnsupportedVersion)(process.version);
	const defaultsMode = (0, import_config.resolveDefaultsModeConfig)(config);
	const defaultConfigProvider = () => defaultsMode().then(import_client$1.loadConfigsForDefaultMode);
	const clientSharedValues = getRuntimeConfig$1(config);
	(0, import_client.emitWarningIfUnsupportedVersion)(process.version);
	const loaderConfig = {
		profile: config?.profile,
		logger: clientSharedValues.logger
	};
	return {
		...clientSharedValues,
		...config,
		runtime: "node",
		defaultsMode,
		authSchemePreference: config?.authSchemePreference ?? (0, import_config.loadConfig)(import_httpAuthSchemes.NODE_AUTH_SCHEME_PREFERENCE_OPTIONS, loaderConfig),
		bodyLengthChecker: config?.bodyLengthChecker ?? import_serde.calculateBodyLength,
		credentialDefaultProvider: config?.credentialDefaultProvider ?? defaultProvider,
		defaultUserAgentProvider: config?.defaultUserAgentProvider ?? (0, import_client.createDefaultUserAgentProvider)({
			serviceId: clientSharedValues.serviceId,
			clientVersion: package_default.version
		}),
		maxAttempts: config?.maxAttempts ?? (0, import_config.loadConfig)(import_retry.NODE_MAX_ATTEMPT_CONFIG_OPTIONS, config),
		region: config?.region ?? (0, import_config.loadConfig)(import_config.NODE_REGION_CONFIG_OPTIONS, {
			...import_config.NODE_REGION_CONFIG_FILE_OPTIONS,
			...loaderConfig
		}),
		requestHandler: NodeHttpHandler.create(config?.requestHandler ?? defaultConfigProvider),
		retryMode: config?.retryMode ?? (0, import_config.loadConfig)({
			...import_retry.NODE_RETRY_MODE_CONFIG_OPTIONS,
			default: async () => (await defaultConfigProvider()).retryMode || import_retry.DEFAULT_RETRY_MODE
		}, config),
		streamCollector: config?.streamCollector ?? import_serde$1.streamCollector,
		useDualstackEndpoint: config?.useDualstackEndpoint ?? (0, import_config.loadConfig)(import_config.NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS, loaderConfig),
		useFipsEndpoint: config?.useFipsEndpoint ?? (0, import_config.loadConfig)(import_config.NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS, loaderConfig),
		userAgentAppId: config?.userAgentAppId ?? (0, import_config.loadConfig)(import_client.NODE_APP_ID_CONFIG_OPTIONS, loaderConfig)
	};
};
//#endregion
//#region node_modules/@aws-sdk/client-sqs/dist-es/auth/httpAuthExtensionConfiguration.js
var getHttpAuthExtensionConfiguration = (runtimeConfig) => {
	const _httpAuthSchemes = runtimeConfig.httpAuthSchemes;
	let _httpAuthSchemeProvider = runtimeConfig.httpAuthSchemeProvider;
	let _credentials = runtimeConfig.credentials;
	return {
		setHttpAuthScheme(httpAuthScheme) {
			const index = _httpAuthSchemes.findIndex((scheme) => scheme.schemeId === httpAuthScheme.schemeId);
			if (index === -1) _httpAuthSchemes.push(httpAuthScheme);
			else _httpAuthSchemes.splice(index, 1, httpAuthScheme);
		},
		httpAuthSchemes() {
			return _httpAuthSchemes;
		},
		setHttpAuthSchemeProvider(httpAuthSchemeProvider) {
			_httpAuthSchemeProvider = httpAuthSchemeProvider;
		},
		httpAuthSchemeProvider() {
			return _httpAuthSchemeProvider;
		},
		setCredentials(credentials) {
			_credentials = credentials;
		},
		credentials() {
			return _credentials;
		}
	};
};
var resolveHttpAuthRuntimeConfig = (config) => {
	return {
		httpAuthSchemes: config.httpAuthSchemes(),
		httpAuthSchemeProvider: config.httpAuthSchemeProvider(),
		credentials: config.credentials()
	};
};
//#endregion
//#region node_modules/@aws-sdk/client-sqs/dist-es/runtimeExtensions.js
var resolveRuntimeExtensions = (runtimeConfig, extensions) => {
	const extensionConfiguration = Object.assign((0, import_client.getAwsRegionExtensionConfiguration)(runtimeConfig), (0, import_client$1.getDefaultExtensionConfiguration)(runtimeConfig), (0, import_protocols$1.getHttpHandlerExtensionConfiguration)(runtimeConfig), getHttpAuthExtensionConfiguration(runtimeConfig));
	extensions.forEach((extension) => extension.configure(extensionConfiguration));
	return Object.assign(runtimeConfig, (0, import_client.resolveAwsRegionExtensionConfiguration)(extensionConfiguration), (0, import_client$1.resolveDefaultRuntimeConfig)(extensionConfiguration), (0, import_protocols$1.resolveHttpHandlerRuntimeConfig)(extensionConfiguration), resolveHttpAuthRuntimeConfig(extensionConfiguration));
};
//#endregion
//#region node_modules/@aws-sdk/client-sqs/dist-es/SQSClient.js
var SQSClient = class extends import_client$1.Client {
	config;
	constructor(...[configuration]) {
		const _config_0 = getRuntimeConfig(configuration || {});
		super(_config_0);
		this.initConfig = _config_0;
		const _config_1 = resolveClientEndpointParameters(_config_0);
		const _config_2 = (0, import_client.resolveUserAgentConfig)(_config_1);
		const _config_3 = (0, import_retry.resolveRetryConfig)(_config_2);
		const _config_4 = (0, import_config.resolveRegionConfig)(_config_3);
		const _config_5 = (0, import_client.resolveHostHeaderConfig)(_config_4);
		const _config_9 = resolveRuntimeExtensions(resolveHttpAuthSchemeConfig(resolveQueueUrlConfig((0, import_endpoints.resolveEndpointConfig)(_config_5))), configuration?.extensions || []);
		this.config = _config_9;
		this.middlewareStack.use((0, import_schema.getSchemaSerdePlugin)(this.config));
		this.middlewareStack.use((0, import_client.getUserAgentPlugin)(this.config));
		this.middlewareStack.use((0, import_retry.getRetryPlugin)(this.config));
		this.middlewareStack.use((0, import_protocols$1.getContentLengthPlugin)(this.config));
		this.middlewareStack.use((0, import_client.getHostHeaderPlugin)(this.config));
		this.middlewareStack.use((0, import_client.getLoggerPlugin)(this.config));
		this.middlewareStack.use((0, import_client.getRecursionDetectionPlugin)(this.config));
		this.middlewareStack.use(getQueueUrlPlugin(this.config));
		this.middlewareStack.use((0, import_dist_cjs.getHttpAuthSchemeEndpointRuleSetPlugin)(this.config, {
			httpAuthSchemeParametersProvider: defaultSQSHttpAuthSchemeParametersProvider,
			identityProviderConfigProvider: async (config) => new import_dist_cjs.DefaultIdentityProviderConfig({ "aws.auth#sigv4": config.credentials })
		}));
		this.middlewareStack.use((0, import_dist_cjs.getHttpSigningPlugin)(this.config));
	}
	destroy() {
		super.destroy();
	}
};
//#endregion
//#region node_modules/@aws-sdk/client-sqs/dist-es/commandBuilder.js
var command = (0, import_client$1.makeBuilder)(commonParams, "AmazonSQS", "SQSClient", import_endpoints.getEndpointPlugin);
var _ep0 = {};
var _mw3 = (Command, cs, config, o) => [getSendMessagePlugin(config)];
//#endregion
//#region node_modules/@aws-sdk/client-sqs/dist-es/commands/SendMessageCommand.js
var SendMessageCommand = class extends command(_ep0, _mw3, "SendMessage", SendMessage$) {};
//#endregion
export { SQSClient as n, SendMessageCommand as t };
