import { r as __exportAll } from "../../_runtime.mjs";
import { d as require_config, l as require_serde, o as require_protocols, r as require_client } from "./checksums+[...].mjs";
import { a as init_dist_es, o as NodeHttpHandler } from "./client-s3+[...].mjs";
import fs from "node:fs/promises";
//#region node_modules/@aws-sdk/credential-provider-http/dist-es/fromHttp/checkUrl.js
var import_serde = require_serde();
var import_protocols = require_protocols();
var import_client = require_client();
init_dist_es();
var import_config = require_config();
var ECS_CONTAINER_HOST = "169.254.170.2";
var EKS_CONTAINER_HOST_IPv4 = "169.254.170.23";
var EKS_CONTAINER_HOST_IPv6 = "[fd00:ec2::23]";
var checkUrl = (url, logger) => {
	if (url.protocol === "https:") return;
	if (url.hostname === ECS_CONTAINER_HOST || url.hostname === EKS_CONTAINER_HOST_IPv4 || url.hostname === EKS_CONTAINER_HOST_IPv6) return;
	if (url.hostname.includes("[")) {
		if (url.hostname === "[::1]" || url.hostname === "[0000:0000:0000:0000:0000:0000:0000:0001]") return;
	} else {
		if (url.hostname === "localhost") return;
		const ipComponents = url.hostname.split(".");
		const inRange = (component) => {
			const num = parseInt(component, 10);
			return 0 <= num && num <= 255;
		};
		if (ipComponents[0] === "127" && inRange(ipComponents[1]) && inRange(ipComponents[2]) && inRange(ipComponents[3]) && ipComponents.length === 4) return;
	}
	throw new import_config.CredentialsProviderError(`URL not accepted. It must either be HTTPS or match one of the following:
  - loopback CIDR 127.0.0.0/8 or [::1/128]
  - ECS container host 169.254.170.2
  - EKS container host 169.254.170.23 or [fd00:ec2::23]`, { logger });
};
//#endregion
//#region node_modules/@aws-sdk/credential-provider-http/dist-es/fromHttp/requestHelpers.js
function createGetRequest(url) {
	return new import_protocols.HttpRequest({
		protocol: url.protocol,
		hostname: url.hostname,
		port: Number(url.port),
		path: url.pathname,
		query: Array.from(url.searchParams.entries()).reduce((acc, [k, v]) => {
			acc[k] = v;
			return acc;
		}, {}),
		fragment: url.hash
	});
}
async function getCredentials(response, logger) {
	const str = await (0, import_serde.sdkStreamMixin)(response.body).transformToString();
	if (response.statusCode === 200) {
		const parsed = JSON.parse(str);
		if (typeof parsed.AccessKeyId !== "string" || typeof parsed.SecretAccessKey !== "string" || typeof parsed.Token !== "string" || typeof parsed.Expiration !== "string") throw new import_config.CredentialsProviderError("HTTP credential provider response not of the required format, an object matching: { AccessKeyId: string, SecretAccessKey: string, Token: string, Expiration: string(rfc3339) }", { logger });
		return {
			accessKeyId: parsed.AccessKeyId,
			secretAccessKey: parsed.SecretAccessKey,
			sessionToken: parsed.Token,
			expiration: (0, import_serde.parseRfc3339DateTime)(parsed.Expiration)
		};
	}
	if (response.statusCode >= 400 && response.statusCode < 500) {
		let parsedBody = {};
		try {
			parsedBody = JSON.parse(str);
		} catch (e) {}
		throw Object.assign(new import_config.CredentialsProviderError(`Server responded with status: ${response.statusCode}`, { logger }), {
			Code: parsedBody.Code,
			Message: parsedBody.Message
		});
	}
	throw new import_config.CredentialsProviderError(`Server responded with status: ${response.statusCode}`, { logger });
}
//#endregion
//#region node_modules/@aws-sdk/credential-provider-http/dist-es/fromHttp/retry-wrapper.js
var retryWrapper = (toRetry, maxRetries, delayMs) => {
	return async () => {
		for (let i = 0; i < maxRetries; ++i) try {
			return await toRetry();
		} catch (e) {
			await new Promise((resolve) => setTimeout(resolve, delayMs));
		}
		return await toRetry();
	};
};
//#endregion
//#region node_modules/@aws-sdk/credential-provider-http/dist-es/fromHttp/fromHttp.js
var AWS_CONTAINER_CREDENTIALS_RELATIVE_URI = "AWS_CONTAINER_CREDENTIALS_RELATIVE_URI";
var DEFAULT_LINK_LOCAL_HOST = "http://169.254.170.2";
var AWS_CONTAINER_CREDENTIALS_FULL_URI = "AWS_CONTAINER_CREDENTIALS_FULL_URI";
var AWS_CONTAINER_AUTHORIZATION_TOKEN_FILE = "AWS_CONTAINER_AUTHORIZATION_TOKEN_FILE";
var AWS_CONTAINER_AUTHORIZATION_TOKEN = "AWS_CONTAINER_AUTHORIZATION_TOKEN";
var fromHttp = (options = {}) => {
	options.logger?.debug("@aws-sdk/credential-provider-http - fromHttp");
	let host;
	const relative = options.awsContainerCredentialsRelativeUri ?? process.env[AWS_CONTAINER_CREDENTIALS_RELATIVE_URI];
	const full = options.awsContainerCredentialsFullUri ?? process.env[AWS_CONTAINER_CREDENTIALS_FULL_URI];
	const token = options.awsContainerAuthorizationToken ?? process.env[AWS_CONTAINER_AUTHORIZATION_TOKEN];
	const tokenFile = options.awsContainerAuthorizationTokenFile ?? process.env[AWS_CONTAINER_AUTHORIZATION_TOKEN_FILE];
	const warn = options.logger?.constructor?.name === "NoOpLogger" || !options.logger?.warn ? console.warn : options.logger.warn.bind(options.logger);
	if (relative && full) {
		warn("@aws-sdk/credential-provider-http: you have set both awsContainerCredentialsRelativeUri and awsContainerCredentialsFullUri.");
		warn("awsContainerCredentialsRelativeUri will take precedence.");
	}
	if (token && tokenFile) {
		warn("@aws-sdk/credential-provider-http: you have set both awsContainerAuthorizationToken and awsContainerAuthorizationTokenFile.");
		warn("awsContainerAuthorizationTokenFile will take precedence.");
	}
	if (relative) host = `${DEFAULT_LINK_LOCAL_HOST}${relative}`;
	else if (full) host = full;
	else throw new import_config.CredentialsProviderError(`No HTTP credential provider host provided.
Set AWS_CONTAINER_CREDENTIALS_FULL_URI or AWS_CONTAINER_CREDENTIALS_RELATIVE_URI.`, { logger: options.logger });
	const url = new URL(host);
	checkUrl(url, options.logger);
	const requestHandler = NodeHttpHandler.create({ connectionTimeout: options.timeout ?? 1e3 });
	const requestTimeout = options.timeout ?? 1e3;
	const provider = retryWrapper(async () => {
		const request = createGetRequest(url);
		if (tokenFile) request.headers.Authorization = validateToken((await fs.readFile(tokenFile)).toString());
		else if (token) request.headers.Authorization = validateToken(token);
		try {
			return getCredentials((await requestHandler.handle(request, { requestTimeout })).response).then((creds) => (0, import_client.setCredentialFeature)(creds, "CREDENTIALS_HTTP", "z"));
		} catch (e) {
			throw new import_config.CredentialsProviderError(String(e), { logger: options.logger });
		}
	}, options.maxRetries ?? 3, options.timeout ?? 1e3);
	return async () => {
		try {
			return await provider();
		} finally {
			requestHandler.destroy?.();
		}
	};
};
var validateToken = (token) => {
	if (token.includes("\r\n")) throw new import_config.CredentialsProviderError("Authorization token contains invalid \\r\\n sequence.");
	return token;
};
//#endregion
//#region node_modules/@aws-sdk/credential-provider-http/dist-es/index.js
var dist_es_exports = /* @__PURE__ */ __exportAll({ fromHttp: () => fromHttp });
//#endregion
export { dist_es_exports as t };
