import { o as __toESM } from "../_runtime.mjs";
import { G as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-sABYIG_N.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var askQuestion = createServerFn().validator((question) => question).handler(createSsrRpc("9d2525a0f0f91d8790297f506f35b21b35c4234edba3b8a7872087a55c57933e"));
var getUploadUrl = createServerFn().validator((filename) => filename).handler(createSsrRpc("387dab4d76f1e6280a76b21c4b3684a08fc5428def3bcd4f4ae7e6a1cc993399"));
var getDocuments = createServerFn().handler(createSsrRpc("89b109b4ae092eb49120e7c38025039f043a02462b83affd9d685c2cfda46dd2"));
function Home() {
	const [status, setStatus] = (0, import_react.useState)("");
	const [documents, setDocuments] = (0, import_react.useState)([]);
	const [chatInput, setChatInput] = (0, import_react.useState)("");
	const [chatHistory, setChatHistory] = (0, import_react.useState)([]);
	const [asking, setAsking] = (0, import_react.useState)(false);
	async function loadDocuments() {
		const docs = await getDocuments();
		setDocuments(docs.map((doc) => ({
			id: doc.id,
			filename: doc.filename,
			status: doc.status,
			created_at: doc.created_at
		})));
	}
	async function handleFileChange(event) {
		const file = event.target.files?.[0];
		if (!file) return;
		setStatus("Requesting upload URL...");
		const { uploadUrl } = await getUploadUrl({ data: file.name });
		setStatus("Uploading...");
		await fetch(uploadUrl, {
			method: "PUT",
			body: file,
			headers: { "Content-Type": "text/markdown" }
		});
		setStatus("Upload complete!");
		await loadDocuments();
	}
	async function handleAsk() {
		if (!chatInput.trim()) return;
		setAsking(true);
		const result = await askQuestion({ data: chatInput });
		setChatHistory((prev) => [...prev, {
			question: chatInput,
			answer: result.answer,
			citations: result.verifiedCitations
		}]);
		setChatInput("");
		setAsking(false);
	}
	(0, import_react.useEffect)(() => {
		loadDocuments();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-4xl font-bold",
				children: "LISA Lite"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "file",
				accept: ".md",
				onChange: handleFileChange
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: status }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: documents.map((doc) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
				doc.filename,
				" — ",
				doc.status
			] }, doc.id)) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl font-bold",
						children: "Ask a question"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "text",
						value: chatInput,
						onChange: (e) => setChatInput(e.target.value),
						placeholder: "Ask something about your documents...",
						className: "border px-2 py-1 mr-2 w-96"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: handleAsk,
						disabled: asking,
						className: "border px-4 py-1",
						children: asking ? "Thinking..." : "Ask"
					}),
					chatHistory.map((entry, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 border-t pt-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Q:" }),
								" ",
								entry.question
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "A:" }),
								" ",
								entry.answer
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: entry.citations.map((c, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-sm text-gray-500",
								children: [
									"[",
									c.number,
									"] ",
									c.valid ? `${c.breadcrumb} (lines ${c.startLine}-${c.endLine})` : "Invalid citation",
									c.quoteSupported === false && " ⚠️ unverified"
								]
							}, j)) })
						]
					}, i))
				]
			})
		]
	});
}
//#endregion
export { Home as component };
